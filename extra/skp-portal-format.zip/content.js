// Create the navigation bar
var navBar = document.createElement('div');
//navBar.style.backgroundColor = 'rgb(30, 30, 44)';
navBar.style.height = '56px';
navBar.style.color = 'white';
navBar.style.display = 'flex';
navBar.style.justifyContent = 'start';
navBar.style.alignItems = 'center';
navBar.style.fontSize = '14px';
navBar.style.gap = '15px';
navBar.style.position = 'fixed'; // Make it stick to the top
navBar.style.width = 'calc(100% - 400px)'; // Make it stretch across the full width of the page
navBar.style.top = '0'; // Position it at the top of the page
navBar.style.zIndex = '1000'; // Make sure it appears above other elements
navBar.style.paddingLeft = '15px';

// Define the headers and corresponding URLs
var headers = {
    'My Portal': 'https://skoop-jira.atlassian.net/wiki/spaces/MP/overview?mode=global',
    'Triage': 'https://skoop-jira.atlassian.net/wiki/spaces/PCO/overview?mode=global',
    'Wiki': 'https://skoop-jira.atlassian.net/wiki/spaces/WIKI/overview?mode=global',
    'General': 'https://skoop-jira.atlassian.net/wiki/spaces/PGEN/overview?mode=global',
    'Tech': 'https://skoop-jira.atlassian.net/wiki/spaces/PTECH/overview?mode=global',
    'Design': 'https://skoop-jira.atlassian.net/wiki/spaces/PDES/overview?mode=global',
    'Routines': 'https://skoop-jira.atlassian.net/wiki/spaces/PASK/overview?mode=global',
    'Products': 'https://skoop-jira.atlassian.net/wiki/spaces/PPO/overview?mode=global'



    // Add the rest of your headers and URLs here
  };
  
  // Add each header to the navigation bar
  for (let header in headers) {
    var div = document.createElement('div');
    div.textContent = header;
    div.style.cursor = 'pointer';
  
    // Add an event listener to navigate to the corresponding URL when clicked
    // wrap the event listener in an immediately invoked function expression (IIFE)
    div.addEventListener('click', (function(headerCopy) {
        return function() {
            window.location.href = headers[headerCopy];
        }
    })(header));
  
    navBar.appendChild(div);
}
  
  // Prepend the navigation bar to the body
  document.body.prepend(navBar);



  
  
