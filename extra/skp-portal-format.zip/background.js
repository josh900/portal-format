chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
  chrome.declarativeContent.onPageChanged.addRules([{
    conditions: [
      new chrome.declarativeContent.PageStateMatcher({
        pageUrl: {hostEquals: 'skoop-jira.atlassian.net'},
      })
    ],
    actions: [new chrome.declarativeContent.ShowPageAction()]
  }]);
});
